import traci
import math

# Detector configurations: IDs, lanes, and entry/exit positions
detectors = {
    "0n0": {
        "lanes": ["gneE1_0", "gneE1_1"],
        "entry": {"gneE1_0": 410.59, "gneE1_1": 410.66},
        "exit": {"gneE1_0": 495.46, "gneE1_1": 495.59},
    },
    "0s0": {
        "lanes": ["gneE5_0", "gneE5_1"],
        "entry": {"gneE5_0": 419.38, "gneE5_1": 419.59},
        "exit": {"gneE5_0": 496.38, "gneE5_1": 496.49},
    },
    "0e0": {
        "lanes": ["gneE3_0", "gneE3_1"],
        "entry": {"gneE3_0": 372.43, "gneE3_1": 372.09},
        "exit": {"gneE3_0": 495.48, "gneE3_1": 495.35},
    },
    "0w0": {
        "lanes": ["gneE7_0", "gneE7_1"],
        "entry": {"gneE7_0": 381.76, "gneE7_1": 381.83},
        "exit": {"gneE7_0": 496.14, "gneE7_1": 496.20},
    },
}

# Define lanes with left-turning vehicles
LEFT_LANES = ["gneE1_1", "gneE3_1", "gneE5_1", "gneE7_1"]

def calculate_angle(current_coords, next_coords):
    """Calculate the angle between two vectors."""
    current_vector = (
        current_coords[-1][0] - current_coords[0][0],
        current_coords[-1][1] - current_coords[0][1],
    )
    next_vector = (
        next_coords[-1][0] - next_coords[0][0],
        next_coords[-1][1] - next_coords[0][1],
    )

    dot_product = current_vector[0] * next_vector[0] + current_vector[1] * next_vector[1]
    magnitude_current = math.sqrt(current_vector[0] ** 2 + current_vector[1] ** 2)
    magnitude_next = math.sqrt(next_vector[0] ** 2 + next_vector[1] ** 2)

    # Ensure cos_angle stays within [-1, 1] to avoid math domain errors

    cos_angle = dot_product / (magnitude_current * magnitude_next)
    cos_angle = max(-1.0, min(1.0, cos_angle))

    return math.degrees(math.acos(cos_angle))

def get_direction(vehicle_id):
    """Determine the direction of the vehicle."""
    # For lanes with straight or right-turning vehicles
    try:
        lane_id = traci.vehicle.getLaneID(vehicle_id)
        if lane_id in ["gneE1_0", "gneE3_0", "gneE5_0", "gneE7_0"]:
            route = traci.vehicle.getRoute(vehicle_id)
            route_index = traci.vehicle.getRouteIndex(vehicle_id)
            next_edge = route[route_index + 1] if route_index + 1 < len(route) else None

            if next_edge:
                current_coords = traci.lane.getShape(lane_id)
                next_coords = traci.lane.getShape(next_edge + "_0")
                angle = calculate_angle(current_coords, next_coords)

                if angle < 10:
                    return "straight"
                elif 80 < angle < 95:
                    return "right"

        elif lane_id in LEFT_LANES:
            return "left"

    except Exception as e:
        print(f"Error determining direction for vehicle {vehicle_id}: {e}")

    return "unknown"

def process_detectors(step, active_vehicle_ids):
    """Process all detectors, count vehicles, and control conflicting vehicles."""
    direction_count = {}
    vehicles_by_lane = {}

    for detector_id, detector_info in detectors.items():
        lanes = detector_info["lanes"]
        exit_positions = detector_info["exit"]
        entry_positions = detector_info["entry"]

        for lane_id in lanes:
            # Filter vehicles in the current lane
            vehicles_in_lane = [
                vehicle_id
                for vehicle_id in active_vehicle_ids
                if traci.vehicle.getLaneID(vehicle_id) == lane_id
            ]
            # Further filter vehicles in the detection range
            vehicles_in_range = [
                v
                for v in vehicles_in_lane
                if entry_positions[lane_id]-20 <= traci.vehicle.getLanePosition(v) <= exit_positions[lane_id]
            ]
            # Sort vehicles by position in descending order
            vehicles_in_range.sort(
                key=lambda v: traci.vehicle.getLanePosition(v), reverse=True
            )
            vehicles_by_lane[lane_id] = vehicles_in_range
            if vehicles_in_range:
                for vehicle_id in vehicles_in_range:
                    direction = get_direction(vehicle_id)
                    if direction != "unknown":
                        direction_count[(direction, lane_id)] = direction_count.get(
                            (direction, lane_id), 0
                        ) + 1
    # Determine the lane and direction with the highest vehicle count
    if direction_count:
        max_direction, max_lane = max(
            direction_count, key=lambda x: direction_count[x]
        )
        print(
            f"Step {step}: Max Direction: {max_direction}, Lane: {max_lane}, Count: {direction_count[(max_direction, max_lane)]}"
        )
        count = vehicles_by_lane[max_lane]
        # Allocate traffic light states
        dynamic_traffic_light_control(
            "1", max_lane,max_direction,count
        )
    else:
        print(f"Step {step}: No vehicles detected.")

def dynamic_traffic_light_control(tl_id, max_lane,max_direction,count):
    """Dynamically control traffic lights."""
    edge_id = traci.lane.getEdgeID(max_lane)

    if edge_id=="gneE1" or edge_id=="gneE5":
        if max_direction=="straight" or max_direction=="right":
            traci.trafficlight.setRedYellowGreenState(tl_id,"GGrrrrGGrrrr")
        elif max_direction=="left":
            traci.trafficlight.setRedYellowGreenState(tl_id,"GrGGrrGrGGrr")
    elif edge_id=="gneE3" or edge_id=="gneE7":
        if max_direction=="straight" or max_direction=="right":
            traci.trafficlight.setRedYellowGreenState(tl_id,"rrrGGrrrrGGr")
        elif max_direction=="left":
            traci.trafficlight.setRedYellowGreenState(tl_id,"GrrGrGGrrGrG")

    traci.simulationStep()

    valid_vehicle_time = [
        (traci.vehicle.getSpeed(vehicle_id)/(501-traci.vehicle.getLanePosition(vehicle_id)))
        for vehicle_id in count
        if vehicle_id in traci.vehicle.getIDList()
    ]
    green_duration = sum(valid_vehicle_time)
    print(green_duration)
    traci.trafficlight.setPhaseDuration(tl_id, green_duration)

if __name__ == "__main__":
    """
    Main function to start the SUMO simulation and manage traffic flow.
    """
    traci.start([
        "sumo-gui", "-c", "data/cross.sumocfg", "--tripinfo-output", "output/0.133.xml"
    ])

    step = 0
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        active_vehicle_ids = traci.vehicle.getIDList()
        process_detectors(step, active_vehicle_ids)
        step += 1

    traci.close()